# NYRIOX — Sua foto pode virar ISSO!

Reel de 20 segundos, 1080 × 1920, 30 fps. Sem locução. Criado a partir do roteiro enviado e da identificação @nyrioxoficial.

## Entregas
- MP4 final H.264/AAC pronto para Reels.
- Capa vertical independente.
- Projeto HTML/GSAP compatível com HyperFrames, imagens e fontes locais.
- Trilhas separadas: música instrumental original, efeitos e mixagem.
- Roteiro original, storyboard/EDL e legenda de publicação.
- Relatório de qualidade, especificações e limitações.

## Editar e renderizar
Requer Node.js 22+, FFmpeg e Chromium/Chrome. Na pasta do projeto:

```sh
npm run dev
npm run check
npm run render
```

O HTML é a fonte editável. Textos comerciais e @ estão em `index.html`. A timeline GSAP ao final define o tempo de cada cena. Todas as imagens e fontes utilizadas estão em `assets/`; não dependem de serviços de geração ao reproduzir.

`build_audio.py` requer numpy e scipy; os SFX originais já acompanham o pacote em `assets/sfx-source/`, sem dependência do computador de produção. O áudio renderizado também acompanha o projeto, portanto não é necessário executar Python para renderizar o filme novamente.

## Identidade e uso
NYRIOX/@nyrioxoficial identifica o anunciante conforme informado pelo usuário. Os produtos AURA, NOIR e ESSENCE são exemplos fictícios gerados por IA, sem afirmação de resultados de clientes. A transformação utiliza a mesma imagem do frasco em duas composições. A animação é 2,5D; não é filmagem do frasco nem rotação física completa em 3D.

A oferta de 4 vídeos por R$ 97 e a legenda reproduzem o roteiro fornecido. A duração de até 30 segundos refere-se ao serviço anunciado; este Reel tem 20 segundos.

Tipografia: Manrope (SIL Open Font License). GSAP acompanha seu cabeçalho de licença; consultar os termos do fornecedor para redistribuição fora deste projeto. Música e SFX procedurais originais, sem samples musicais externos.
