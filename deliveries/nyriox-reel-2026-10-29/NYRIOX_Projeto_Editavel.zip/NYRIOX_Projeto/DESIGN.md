# NYRIOX — Sua foto pode virar ISSO

## Style Prompt
Publicidade vertical de cosméticos, com fotografia de produto fictício e transformação de catálogo off-white para uma composição de luxo em preto profundo e ouro acetinado. O frasco AURA permanece idêntico nas duas apresentações. Hierarquia ampla, luz lateral, partículas raras e movimentos com desaceleração. A marca anunciada é @nyrioxoficial; AURA, NOIR e ESSENCE são apenas produtos demonstrativos fictícios.

## Colors
- #08090b: fundo preto principal.
- #e5c58c: ouro claro para títulos e oferta.
- #a78247: ouro profundo para detalhes decorativos.
- #f3f1ec: off-white para abertura e textos claros.
- #a8a49b: texto secundário em fundo escuro.

## Typography
Manrope variável para toda a comunicação comercial. Títulos 70–110 px, preço 220 px, apoio 30–42 px. Oferta sem fonte decorativa. Números tabulares.

## Motion
Gancho por palavras; suspense 3–5 s; match zoom de 0,55 s na transformação; movimento suave de perspectiva e reflexo luminoso no produto; recuo para três peças verticais em 11 s. Oferta estável até o CTA, com repetição discreta de preço no encerramento. Último segundo estático.

## What NOT to Do
- Não adicionar locução ou letra à música.
- Não mudar embalagem entre antes e depois.
- Não adicionar promessas de vendas, depoimentos ou percentuais.
- Não usar partículas sobre o preço ou o direct.
- Não usar flashes estroboscópicos ou interfaces falsas.
