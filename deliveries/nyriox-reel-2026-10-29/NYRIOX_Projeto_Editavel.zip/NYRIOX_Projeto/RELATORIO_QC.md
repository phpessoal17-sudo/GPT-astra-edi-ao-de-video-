# Controle de qualidade — NYRIOX

## Resultado técnico
- Duração exata: 20,000 s; 600 quadros, 30 fps constantes.
- Resolução: 1080 × 1920, proporção 9:16.
- Vídeo: H.264, yuv420p, Rec.709, níveis limitados.
- Áudio: AAC estéreo, 48 kHz, 256 kb/s.
- Loudness do arquivo AAC: −16,5 LUFS integrados.
- True peak do arquivo AAC: −2,2 dBTP.
- Duração de vídeo e áudio: 20,000 s em ambos os fluxos.
- Decodificação completa: zero erros reportados pelo FFmpeg.
- Final estático: a última animação termina em 18,95 s; quadro mantido até 20 s.

## Revisão de composição
Revisados quadros da abertura, pergunta, transformação, mensagens, vitrine, oferta e CTA. Texto principal em área segura, oferta em bloco separado e @nyrioxoficial conferido. Mesma imagem do frasco usada nas duas apresentações.

HyperFrames check: runtime, layout e contraste sem erros. O lint registra dois avisos de reutilização da mesma imagem: uso intencional para comparar antes/depois, refletir o produto e recortar os dois produtos demonstrativos nos painéis. O layout registra entradas/clipping dos painéis laterais e sobreposição da vitrine de forma intencional. Tipografia diminuta dentro do anúncio reduzido é parte da miniatura; a mensagem comercial principal aparece em tamanho grande fora dos painéis.

O mapa de animação está em animation-map.json. A duração da timeline animada é 18,95 s, enquanto a duração de exportação definida na raiz é 20 s; essa diferença é a pausa estática solicitada no encerramento.

## Origem e limites
- Direção de arte e EDL seguem o roteiro do usuário. Nome do perfil confirmado na conversa.
- Imagens geradas com OpenAI; três produtos fictícios.
- Animação 2,5D em HTML/GSAP; nenhuma filmagem, avatar, locução ou simulação de depoimento.
- Música e efeitos de síntese procedural original. Sem canção comercial ou sample musical externo.
- Preço e condições vieram do material do anunciante; nenhuma alegação de retorno financeiro adicionada.
- Medições automáticas e revisão de quadros não equivalem a aprovação artística/auditiva humana. Não foi realizada audição humana.
- Não houve publicação no Instagram nem compartilhamento público dos arquivos.
