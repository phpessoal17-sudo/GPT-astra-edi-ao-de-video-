# Roteiro e EDL — 20 segundos, 1080 × 1920, 30 fps

Fonte: Texto colado.txt, preservado no pacote. Identificação adicional fornecida pelo usuário: @nyrioxoficial.

| Tempo | Direção visual | Texto principal | Som |
|---|---|---|---|
| 0–3 | Fundo off-white, embalagem pequena, dessaturada, quadro de catálogo e aproximação mínima | Você ainda divulga seus produtos assim? | Clique de entrada, ambiente musical contido |
| 3–5 | Fundo escurece; ouro contorna produto; frase monumental | E se virasse ISSO? | Riser em crescendo |
| 5–7 | Mesmo frasco cresce em match zoom, pedestal reflexivo e luz dourada | Apresentação do resultado | Impacto, subgrave e começo da batida |
| 7–9 | Packshot com luz móvel e perspectiva sutil | Mais destaque. | Batida e brilho discreto |
| 9–11 | Continua a fotografia com mudança de mensagem | Mais presença para sua marca. | Pulso e pequeno whoosh |
| 11–14 | Frasco recua para vitrine com perfume e creme; três peças verticais em movimento | Transformamos fotos em vídeos comerciais. | Entradas alternadas sincronizadas |
| 14–17 | Fundo preto, filetes dourados, oferta central | Seu produto também pode ter essa apresentação. / 4 VÍDEOS / R$ 97 / Pagamento único • Sem mensalidade | Impacto suave e música reduzida |
| 17–20 | Assinatura, pergunta e botão ouro; oferta resumida continua como apoio | @nyrioxoficial / Quer um vídeo assim para sua marca? / PEÇA PELO DIRECT | Chime de conclusão; último segundo estático |

## Evidências e decisões
- **Verificado na fonte:** duração, formato, ausência de voz, paleta, textos, R$ 97, 4 vídeos e pagamento único sem mensalidade.
- **Preferência explícita:** motion design premium e direção minimalista.
- **Verificado na conversa:** @nyrioxoficial no encerramento.
- **Hipótese editorial:** 30 fps é adequado ao destino Reels; sem arquivo de câmera a preservar.
- **Experimento criativo:** produtos fictícios gerados por IA e animação de câmera 2,5D; sem alegação de filmagem real ou demonstração de cliente anterior.
- A oferta da fonte é reproduzida como instrução do anunciante; não foi auditada externamente.

## Fontes editáveis
index.html contém layout e timeline GSAP; assets contém imagens originais e tipografia; build_audio.py gera trilha e efeitos; render.mjs permite captura determinística com Playwright e FFmpeg quando a CLI HyperFrames não estiver disponível.
