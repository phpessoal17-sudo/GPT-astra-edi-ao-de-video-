// Fallback capture independent of HyperFrames CLI; deterministic GSAP seeking.
import {createRequire} from 'node:module';import {spawn} from 'node:child_process';import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import http from 'node:http';
const require=createRequire(import.meta.url),{chromium}=require('playwright');
const root=path.dirname(fileURLToPath(import.meta.url));
const mode=process.argv[2]||'snapshots';
const server=http.createServer((req,res)=>{const rel=decodeURIComponent((req.url||'/').split('?')[0]);const file=path.join(root,rel==='/'?'index.html':rel);if(!file.startsWith(root)||!fs.existsSync(file)){res.writeHead(404).end();return}const ext=path.extname(file);res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.png':'image/png','.ttf':'font/ttf','.wav':'audio/wav'})[ext]||'application/octet-stream');fs.createReadStream(file).pipe(res)});await new Promise(r=>server.listen(0,'127.0.0.1',r));
const browser=await chromium.launch({...(process.env.CHROMIUM_PATH?{executablePath:process.env.CHROMIUM_PATH}:fs.existsSync('/usr/bin/chromium')?{executablePath:'/usr/bin/chromium'}:{}),headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--allow-file-access-from-files']});
const page=await browser.newPage({viewport:{width:1080,height:1920},deviceScaleFactor:1});
console.log('Navigate');await page.goto('http://127.0.0.1:'+server.address().port+'/',{waitUntil:'domcontentloaded'});console.log('Fonts');await page.evaluate(()=>document.fonts.ready.then(()=>true));console.log('Images');await page.evaluate(()=>Promise.all(Array.from(document.images).map(i=>i.decode().catch(()=>{}))).then(()=>true));console.log('Ready');
fs.mkdirSync(root+'/review',{recursive:true});
const cdp=await page.context().newCDPSession(page);
const capture=async()=>Buffer.from((await cdp.send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false})).data,'base64');
if(mode==='snapshots'){
for(const t of [.9,2.5,4.2,5.6,7.8,9.9,12.5,15.6,18.9,19.9]){await page.evaluate(t=>window.seekFilm(t),t);fs.writeFileSync(root+'/review/'+String(t)+'.png',await capture());}
const result=await page.evaluate(()=>({width:document.getElementById('film').offsetWidth,height:document.getElementById('film').offsetHeight,duration:window.__timelines.nyriox.duration(),font:document.fonts.check('700 80px Manrope')}));console.log(result);
const map=await page.evaluate(()=>window.__timelines.nyriox.getChildren(true,true,false).map(t=>({targets:t.targets().map(e=>e.id?'#'+e.id:'.'+e.className),start:t.startTime(),duration:t.duration(),end:t.endTime(),properties:Object.keys(t.vars).filter(k=>!['duration','ease','immediateRender','repeat','yoyo','parent','startAt','runBackwards','stagger'].includes(k)),ease:String(t.vars.ease||'default')})));
fs.writeFileSync(root+'/animation-map.json',JSON.stringify(map,null,2));
}else{
const output=process.argv[3]||root+'/silent.mp4';
const enc=spawn('ffmpeg',['-y','-f','image2pipe','-vcodec','png','-r','30','-i','-','-an','-c:v','libx264','-preset','fast','-crf','17','-pix_fmt','yuv420p','-r','30',output],{stdio:['pipe','ignore','inherit']});
for(let f=0;f<600;f++){await page.evaluate(t=>window.seekFilm(t),f/30);const shot=await capture();if(!enc.stdin.write(shot))await new Promise(r=>enc.stdin.once('drain',r));if(f%60===0)console.log('Frame',f,'/600');}
enc.stdin.end();await new Promise((resolve,reject)=>enc.on('exit',code=>code?reject(Error(String(code))):resolve()));
}await browser.close();server.close();
