"""Original 20-second instrumental cue, 120 BPM reveal at exactly 5 seconds.
No sampled recordings. numpy/scipy synthesis plus original Masterpiece SFX.
"""
from pathlib import Path
import numpy as np
from scipy.signal import butter, sosfilt
from scipy.io import wavfile

ROOT=Path(__file__).resolve().parent
SR=48000; N=SR*20
rng=np.random.default_rng(294390)
music=np.zeros((N,2),np.float64); fx=np.zeros_like(music)

def put(bus,x,at,gain=1,pan=0):
    if x.ndim==1:
        x=np.column_stack((x*np.sqrt((1-pan)/2),x*np.sqrt((1+pan)/2)))
    i=round(at*SR); length=min(len(x),N-i)
    if length>0: bus[i:i+length]+=x[:length]*gain

def tone(freq,dur,kind='pad'):
    t=np.arange(round(dur*SR))/SR
    if kind=='pad':
        sig=sum(np.sin(2*np.pi*freq*r*t+p)*a for r,a,p in [(1,.65,0),(1.003,.22,.3),(.997,.22,1),(2,.13,.2),(3,.025,1)])
        env=np.minimum(t/.6,1)*np.minimum((dur-t)/1.2,1)
    else:
        sig=np.sin(2*np.pi*freq*t)+.25*np.sin(2*np.pi*2*freq*t)+.08*np.sin(2*np.pi*4*freq*t)
        env=np.minimum(t/.004,1)*np.exp(-t*5.5)
    return sig*env

def hz(m):return 440*2**((m-69)/12)

for start,chord in [(0,[48,55,58,62]),(5,[48,55,58,62]),(9,[44,51,55,60]),(13,[46,53,58,62]),(17,[48,55,58,62])]:
    dur=min(5,20-start)
    for j,m in enumerate(chord):put(music,tone(hz(m),dur),start,.055,[-.65,.5,-.2,.7][j])

# Restrained, syncopated glass plucks with stereo delay.
notes=[72,79,82,86,79,74,82,79]
for k in range(29):
    at=5+k*.5
    if at>=18.8:break
    p=tone(hz(notes[k%8]),1.3,'pluck')
    gain=.09 if k%2==0 else .047
    pan=(-.42 if k%2 else .42)
    put(music,p,at,gain,pan)
    for d,g in [(.25,.28),(.5,.13),(.75,.06)]:put(music,p,at+d,gain*g,-pan)

def kick():
    t=np.arange(int(.48*SR))/SR
    phase=2*np.pi*(48*t+70*.026*(1-np.exp(-t/.026)))
    return np.sin(phase)*np.exp(-t*12)+rng.normal(0,1,len(t))*.03*np.exp(-t*130)
def snare():
    t=np.arange(int(.23*SR))/SR
    noise=sosfilt(butter(2,1700,fs=SR,btype='high',output='sos'),rng.normal(0,1,len(t)))
    return .34*noise*np.exp(-t*24)+.18*np.sin(2*np.pi*185*t)*np.exp(-t*28)
def hat():
    t=np.arange(int(.095*SR))/SR
    noise=sosfilt(butter(2,7000,fs=SR,btype='high',output='sos'),rng.normal(0,1,len(t)))
    return noise*np.exp(-t*68)
for k in range(27):
    at=5+k*.5
    if at>18:break
    duck=.65 if at>=14 else 1
    if k%4 in (0,2):put(music,kick(),at,.6*duck)
    if k%4 in (1,3):put(music,snare(),at,.35*duck,.08)
    put(music,hat(),at,.095*duck,-.3)
    if at<17:put(music,hat(),at+.25,.055*duck,.4)
for at,m in [(5,36),(7,36),(9,32),(11,32),(13,34),(15,34),(17,36)]:
    t=np.arange(int(1.7*SR))/SR
    bass=(np.sin(2*np.pi*hz(m)*t)+.16*np.sin(2*np.pi*2*hz(m)*t))*np.minimum(t/.015,1)*np.exp(-t*2)
    put(music,bass,at,.22)

LIB=ROOT/'assets'/'sfx-source'
def sfx(name,at,gain):
    rate,x=wavfile.read(LIB/(name+'.wav'))
    if np.issubdtype(x.dtype,np.integer):x=x.astype(float)/np.iinfo(x.dtype).max
    if rate!=SR:raise ValueError('unexpected source rate')
    put(fx,x,at,gain)
for name,at,g in [('click_glass',.18,.35),('riser_glass',3.2,.65),('whoosh_soft_air',4.66,.35),('impact_cinematic',5,.65),('sub_drop',5,.3),('sparkle_cluster',6.9,.14),('whoosh_soft_air',8.95,.15),('whoosh_fast_tonal',10.95,.28),('page_swipe',11.35,.12),('impact_soft',14,.4),('data_pop',14.4,.2),('confirm_chime',17.5,.3)]:sfx(name,at,g)

t=np.arange(N)/SR
level=np.where(t<3,.3,np.where(t<5,.45,np.where(t<14,1,.78)))
music*=level[:,None]
tail=np.clip((20-t)/.8,0,1)
music*=tail[:,None];fx*=tail[:,None]
mix=np.tanh((music+fx)*1.15)
mix*=min(1,.87/np.max(np.abs(mix)))
for name,x in [('music-original',music),('sfx',fx),('mix',mix)]:
    wavfile.write(ROOT/'assets'/f'{name}.wav',SR,(np.clip(x,-1,1)*32767).astype(np.int16))
print('20 s / 48 kHz stereo: music, SFX, mix')

# Master conservador, com margem para os picos do encode AAC.
import subprocess
raw=ROOT/'assets'/'mix-source.wav'
(ROOT/'assets'/'mix.wav').replace(raw)
subprocess.run(['ffmpeg','-hide_banner','-y','-i',str(raw),'-af','loudnorm=I=-16:TP=-2.5:LRA=9:measured_I=-20.78:measured_TP=-3.06:measured_LRA=5.40:measured_thresh=-31.59:offset=0.27:linear=false','-ar','48000','-c:a','pcm_s24le',str(ROOT/'assets'/'mix.wav')],check=True)
