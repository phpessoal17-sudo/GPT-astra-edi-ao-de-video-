# Criativo — Sal Amargo em cápsulas

Peça vertical de 15 segundos: foto real do produto, animações e edição por código, trilha instrumental original e SFX originais. Direção principal: DNA v9, com fundo verde/cinza claro, faixa verde, recorte central, contraste sans/serifada itálica e entrada vertical baseada na trajetória medida da referência.

## Arquivos

- `sal-amargo-criativo.mp4`: entrega 720×1280, 30 fps, H.264/AAC.
- `sal-amargo-previa.mp4`: prévia 360×640 com a mesma montagem e áudio.
- `roteiro.md`, `edl.json`, `brief.json`: intenção, tempos, regras e parâmetros.
- `src/render.py`: fonte completa de animação, composição musical, SFX, mix e render.
- `assets/`: original preservado, stems de áudio e proveniência.
- `style/v9.json`: DNA copiado do estudo das referências; mantém IDs de origem e lookup de movimento.
- `qc.json`: metadados, hash e loudness medido depois do AAC.
- `AGENTS.md`: instruções persistentes deste projeto. O workspace também possui `AGENTS.md` e `output/VIDEO_PRODUCTION_WORKFLOW.md` para as próximas peças.

## Reconstrução

Ambiente verificado: Linux, Python 3.12, FFmpeg/FFprobe 7.1.5, fontes Liberation Sans e Liberation Serif. Dependências exatas em `requirements.txt`.

```
python -m pip install -r requirements.txt
python src/render.py --frames-only
python src/render.py --preview
python src/render.py
```

O renderer recusa sobrescrever um MP4 existente. Para refazer a peça, preserve/renomeie o export anterior ou use uma cópia do projeto. Intermediários são gerados na pasta `work/` do diretório de execução. Fontes são resolvidas nos diretórios Liberation do sistema; não há instalação nativa num NLE.

## Decisões reais de produção

- Roteiro restringido ao nome e ao formato legíveis na embalagem, com um CTA genérico. Nenhum benefício de saúde, dosagem, preço, oferta, contagem ou certificação foi inventado.
- A foto original de 240×240 foi mantida. Um recorte/ampliação por ImageGen foi inspecionado e rejeitado por alterar microtexto; ele não aparece no vídeo.
- A máscara de silhueta é uma camada de composição. Rótulo e RGB originais não são redesenhados; o detalhe disponível continua limitado pela imagem de origem.
- O catálogo de áudio do HeyGen foi consultado, mas o download retornou bloqueio 403. Nenhum áudio de catálogo foi apresentado como incorporado. A alternativa entregue é música/SFX sintetizados por código, com seed e stems preservados.
- Não há locução nesta versão. Textos são títulos editoriais, não legendas de uma fala inexistente.
- O áudio é proposta nova para este produto, sem alegar que os sons não escutados integralmente da referência foram reconstruídos.

## Skills e ferramentas utilizados

Masterpiece Video Engine (roteiro/EDL/QC), HeyGen Script Writer, Motion Graphics e Video Editing (escrita, composição em Python e finishing); ImageGen para tentativa de recorte, rejeitada após revisão; HeyGen audio catalog para busca; Python/NumPy/SciPy/Pillow e FFmpeg para a peça entregue. O projeto documenta o que foi efetivamente executado e o que foi descartado.

As verificações técnicas incluem decodificação completa, duração, geometria, stream de áudio e loudness/true peak pós-AAC. Quadros e transições foram inspecionados. Não se declara sessão de escuta humana integral ou identidade exata com o áudio das referências.
