# Criativo Sal Amargo

- Ler `WORKFLOW.md`, `brief.json`, `roteiro.md` e `edl.json`.
- Direção principal: DNA v9 — produto recortado, cinza/verde claro, faixa verde, contraste sans/serifada itálica, entradas verticais, escala e sustentação. Não aplicar estética vermelha v3/v10 neste anúncio sem pedido explícito.
- A foto original tem 240×240 pixels. Não trocar o rótulo por texto gerado nem inventar verso, conteúdo interno ou cápsulas reais não fornecidas.
- Composição autorizada por código: máscara de silhueta, escala, posição, rotação 2D, recortes, sombra, fundos, formas geométricas, títulos e transições.
- Áudio: trilha e SFX originais sintetizados por código; catálogo consultado mas download bloqueado. Não declarar uso efetivo desses arquivos.
- Arquivar a tentativa de recorte IA como rejeitada: alterou microtexto. Usar somente a foto original na peça entregue.
- Sem afirmações terapêuticas, posologia, oferta, preço, contagem de cápsulas ou certificação não confirmadas. CTA genérico “Conheça o produto”.
- Reconstrução: `python src/render.py`; dependências e parâmetros em arquivos locais. Não sobrescrever originais.

