# Pacote editavel para download no GitHub

Este pacote preserva o video final, previa, fonte Python, EDL, roteiro, foto original, DNA v9, stems separados de musica e efeitos sonoros, e relatorios de validacao.

Para caber no limite de envio de 16 MiB do conector, somente assets/mix_raw.wav e assets/mix_master.wav foram excluidos. Sao mixagens intermediarias regeneradas por `python src/render.py`, conforme README.md. A musica e os efeitos originais permanecem completos e sem alteracao.

FILE_MANIFEST.json documenta a renderizacao original e inclui as duas mixagens. PACKAGE_CONTENTS.json lista os arquivos efetivamente presentes neste pacote. Os CRCs originais dos arquivos preservados continuam identicos.

O MP4 entregue tem 15 segundos, 720x1280, 30 FPS, trilha e SFX. Nenhuma alteracao foi feita na imagem, no audio ou na edicao do MP4.
