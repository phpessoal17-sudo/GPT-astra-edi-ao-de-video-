# Aplicação e limites do DNA

| Dimensão | Aplicação nesta peça | Origem/limite |
|---|---|---|
| Temporal | Cinco composições de 2,4–3,6 s, movimentos internos e sustentação do CTA | A cadência foi adaptada à apresentação do produto; não se copiou numericamente cada corte da referência |
| Motion | Lookup medido v9 com tempo/amplitude adaptados; reenquadramento, escala, entrada vertical e pequenas rotações 2D | `style/v9.json`, `v9.motion.track.green-logo`; não são keyframes originais do editor |
| Visual | Fundo claro, verde da embalagem, faixa atrás do produto, motivo circular e sombra | v9.event.001/002/003, adaptados ao produto real |
| Tipografia | Sans inclinada de apoio e serifada itálica de destaque | Equivalentes Liberation; fonte exata da referência não comprovada |
| Composição | Produto central, macro em cartão e cópias parciais fora das bordas | Lógica de recorte/escala v9; as cópias são elementos gráficos do mesmo frasco |
| Transição | Reenquadramentos duros, blur curto e passagem vertical do cartão | Linguagem observada, sem nomes de presets supostos |
| Áudio | Partitura instrumental nova a 104 BPM e SFX motivados por eventos | Criados por código. BPM e timbres são propostos para esta peça, não medições do áudio v9 |
| Narrativa | Curiosidade → formato confirmado → detalhe real → identidade → CTA | Novo roteiro, sem alegações comerciais/terapêuticas acrescentadas |

A embalagem vem da foto fornecida e seu RGB não foi redesenhado. A baixa resolução limita o detalhe recuperável; a exportação maior não é apresentada como nova informação de imagem. A peça aplica a linguagem do DNA aos materiais disponíveis, sem prometer equivalência integral de todas as composições/sons da referência.
