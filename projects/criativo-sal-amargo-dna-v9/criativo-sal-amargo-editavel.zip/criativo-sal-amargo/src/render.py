#!/usr/bin/env python3
"""Criativo Sal Amargo: timed 2D compositing, original score/SFX, FFmpeg export.

Run from the project root: python src/render.py
No generative replacement of the product or label is used in the delivery.
"""
import argparse,hashlib,json,math,pathlib,subprocess,sys,wave
from functools import lru_cache
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
from scipy.io import wavfile

ROOT=pathlib.Path(__file__).resolve().parents[1]
CFG=json.loads((ROOT/'brief.json').read_text());EDL=json.loads((ROOT/'edl.json').read_text())
DNA=json.loads((ROOT/CFG['style_reference']).read_text())
FPS=30;DURATION=15;RATE=48000
FONTROOT=pathlib.Path('/usr/share/fonts/truetype/liberation')
if not FONTROOT.exists():FONTROOT=pathlib.Path('/usr/share/fonts/truetype/liberation2')
W,H=720,1280;S=1.

def command(args):
 r=subprocess.run([str(x) for x in args],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if r.returncode:raise RuntimeError(r.stderr.decode(errors='replace')[-2400:])
 return r.stdout

def clamp(x):return max(0.,min(1.,x))
def ease(x):return 1-(1-clamp(x))**3
def measured_entry(x):
 curve=DNA['execution']['motion']['entry_curve']
 return float(np.interp(clamp(x),[p[0] for p in curve],[p[1] for p in curve]))
def rgb(value):return tuple(bytes.fromhex(value.lstrip('#')))
def px(x):return round(x*S)

@lru_cache(maxsize=160)
def fnt(name,size):return ImageFont.truetype(str(FONTROOT/name),px(size))

@lru_cache(maxsize=100)
def text_asset(text,size,kind='sans',color='ink'):
 name=CFG['style'][kind];face=fnt(name,size);box=face.getbbox(text,stroke_width=0);pad=px(6)
 im=Image.new('RGBA',(max(1,box[2]-box[0]+pad*2),max(1,box[3]-box[1]+pad*2)))
 ImageDraw.Draw(im).text((pad-box[0],pad-box[1]),text,font=face,fill=CFG['style'].get(color,color))
 return im

def paste_center(dst,src,x,y,opacity=1,angle=0):
 if opacity<=0:return
 if angle:src=src.rotate(angle,Image.Resampling.BICUBIC,expand=True)
 if opacity<.999:
  src=src.copy();src.putalpha(src.getchannel('A').point(lambda a:round(a*clamp(opacity))))
 dst.alpha_composite(src,(round(x-src.width/2),round(y-src.height/2)))

def text(dst,phrase,x,y,size,kind='sans',color='ink',opacity=1,local=None,delay=0):
 if local is not None:
  e=ease((local-delay)/.28);opacity*=e;y+=(1-e)*px(24)
 paste_center(dst,text_asset(phrase,size,kind,color),x,y,opacity)

@lru_cache(maxsize=1)
def product():
 """Non-destructive alpha matte; source RGB and printed label are unchanged."""
 im=Image.open(ROOT/'assets/produto-original.jpg').convert('RGBA')
 # Silhouette traced in original 240px coordinates. This is a compositing matte,
 # not a generated replacement product and not invented back/side geometry.
 outline=[(84,14),(94,12),(147,12),(156,15),(158,21),(158,36),(155,41),(150,43),(150,48),(160,51),(169,57),(173,66),(174,84),(174,204),(172,214),(165,219),(150,223),(94,223),(78,220),(70,216),(67,209),(68,81),(69,68),(73,58),(82,52),(89,48),(89,44),(83,41),(81,36),(81,20)]
 matte=Image.new('L',(960,960));ImageDraw.Draw(matte).polygon([(x*4,y*4) for x,y in outline],fill=255);matte=matte.filter(ImageFilter.GaussianBlur(.85)).resize((240,240),Image.Resampling.LANCZOS)
 im.putalpha(matte);return im.crop((61,7,181,229))

@lru_cache(maxsize=180)
def product_sized(height,blur=0):
 p=product();p=p.resize((max(1,round(p.width*height/p.height)),height),Image.Resampling.LANCZOS)
 return p.filter(ImageFilter.GaussianBlur(blur)) if blur else p

def bottle(dst,cx,cy,height,opacity=1,angle=0,blur=0,shadow=True):
 h=round(height);p=product_sized(h,round(blur,1))
 if shadow:
  sh=Image.new('RGBA',p.size,(12,39,23,0));a=p.getchannel('A').point(lambda v:round(v*.20));sh.putalpha(a);sh=sh.filter(ImageFilter.GaussianBlur(px(13)))
  paste_center(dst,sh,cx+px(14),cy+px(20),opacity,angle)
 paste_center(dst,p,cx,cy,opacity,angle)

@lru_cache(maxsize=1)
def bg():
 yy,xx=np.mgrid[0:H,0:W];rad=((xx-W*.5)/W)**2+((yy-H*.47)/H)**2;base=np.array(rgb(CFG['style']['background']),float);arr=np.clip(base[None,None,:]*(1-.12*rad[:,:,None]),0,255).astype('uint8');return Image.fromarray(arr).convert('RGBA')

def background(t):
 im=bg().copy();d=ImageDraw.Draw(im)
 # A restrained, translucent circular motif echoes the real label geometry.
 cx=W*(.5+.025*math.sin(t*.22));cy=H*.56;radius=px(275)
 rings=Image.new('RGBA',(W,H));dr=ImageDraw.Draw(rings);dr.ellipse((cx-radius,cy-radius,cx+radius,cy+radius),outline=(106,145,117,22),width=px(55));dr.ellipse((cx-radius*.7,cy-radius*.7,cx+radius*.7,cy+radius*.7),outline=(103,144,115,13),width=px(2));im.alpha_composite(rings)
 # Green ribbon remains behind the factual product, as in v9.
 ribbon=Image.new('RGBA',(W,H));dr=ImageDraw.Draw(ribbon);pts=[]
 for j in range(100):
  x=W*(j/99*1.4-.2);y=H*(.57+.19*math.sin((j/99)*2.2+1.2+t*.065));pts.append((x,y))
 dr.line(pts,fill=CFG['style']['accent'],width=px(48),joint='curve');im.alpha_composite(ribbon)
 return im

def matte_card(image,size,radius):
 image=image.resize(size,Image.Resampling.LANCZOS).convert('RGBA');mask=Image.new('L',size);ImageDraw.Draw(mask).rounded_rectangle((0,0,size[0]-1,size[1]-1),radius,fill=255);image.putalpha(mask);return image

@lru_cache(maxsize=1)
def detail_card():
 # Preserve original raster: no AI text, no sharpening that invents fine print.
 original=Image.open(ROOT/'assets/produto-original.jpg');crop=original.crop((67,62,175,200));return matte_card(crop,(px(438),px(560)),px(35))

def scene(index,local):
 fg=Image.new('RGBA',(W,H));floaty=px(4)*math.sin(local*1.65);lines=EDL['scenes'][index]['text']
 if index==0:
  e=measured_entry(local/CFG['motion']['opening_duration_s'])
  text(fg,lines[0],W*.5,H*.16,29,'sans_italic',local=local,delay=.05)
  text(fg,lines[1],W*.5,H*.235,76,'serif_italic',local=local,delay=.13)
  bottle(fg,W*.5,H*.62+px(CFG['motion']['opening_offset_y_px_at_720'])*(1-e)+floaty,px(635)*(1+.025*clamp(local/2.4)),angle=(1-e)*-5)
 elif index==1:
  e=ease(local/.32)
  bottle(fg,W*.14-px(20)*(1-e),H*.56+floaty,px(800+18*local),blur=px(3)*(1-e))
  text(fg,lines[0],W*.68,H*.39,34,'sans_italic',local=local,delay=.04)
  text(fg,lines[1],W*.66,H*.46,75,'serif_italic',local=local,delay=.16)
 elif index==2:
  text(fg,lines[0],W*.5,H*.15,31,'sans_italic',local=local,delay=.08)
  text(fg,lines[1],W*.5,H*.224,77,'serif_italic',local=local,delay=.18)
  e=measured_entry(local/CFG['motion']['detail_entry_duration_s']);y=H*.565+H*CFG['motion']['detail_offset_y_norm']*(1-e);card=detail_card()
  shadow=Image.new('RGBA',card.size,(0,0,0,85));shadow.putalpha(card.getchannel('A').point(lambda a:round(a*.2)));shadow=shadow.filter(ImageFilter.GaussianBlur(px(15)));paste_center(fg,shadow,W*.5+px(12),y+px(16));paste_center(fg,card,W*.5,y)
  # One dotted arc points to a visible label detail, not a quantitative claim.
  dr=ImageDraw.Draw(fg);radius=px(255);cx=W*.5;cy=y
  for j in range(round(44*ease((local-.45)/.55))):
   theta=math.radians(-130+j*5);xx=cx+radius*math.cos(theta);yy=cy+radius*math.sin(theta);rr=px(1.5);dr.ellipse((xx-rr,yy-rr,xx+rr,yy+rr),fill=(52,83,63,170))
 elif index==3:
  bottle(fg,-px(18),H*.30,px(370),opacity=.42,angle=-18,blur=px(2),shadow=False)
  bottle(fg,W+px(12),H*.82,px(405),opacity=.45,angle=16,blur=px(1.8),shadow=False)
  text(fg,lines[0],W*.5,H*.16,77,'serif_italic',local=local,delay=.02)
  text(fg,lines[1],W*.5,H*.235,32,'sans_italic',local=local,delay=.16)
  e=ease(local/.30);bottle(fg,W*.5,H*.615+floaty,px(665)*(1+.02*clamp(local/3.2)),blur=px(3)*(1-e))
 else:
  text(fg,lines[0],W*.5,H*.15,31,'sans_italic',local=local,delay=.02)
  text(fg,lines[1],W*.5,H*.225,78,'serif_italic',local=local,delay=.15)
  e=ease(local/.38);bottle(fg,W*.5,H*.55+px(40)*(1-e)+floaty,px(570))
  button=Image.new('RGBA',(px(376),px(82)));dr=ImageDraw.Draw(button);dr.rounded_rectangle((0,0,button.width-1,button.height-1),px(41),fill=CFG['style']['accent']);label=text_asset(lines[2],32,'sans','#ffffff');paste_center(button,label,button.width*.46,button.height*.50);xx=button.width*.83;yy=button.height*.5;dr.line([(xx-px(9),yy-px(8)),(xx,yy),(xx-px(9),yy+px(8))],fill='white',width=px(2))
  be=ease((local-.42)/.28);paste_center(fg,button,W*.5,H*.855+px(18)*(1-be),be)
 return fg

def image_at(frame):
 t=frame/FPS;im=background(t);index=max(i for i,s in enumerate(EDL['scenes']) if s['start_s']<=t);info=EDL['scenes'][index];local=t-info['start_s'];fg=scene(index,local)
 if index==2 and local<.25:
  outgoing=scene(1,EDL['scenes'][1]['end_s']-EDL['scenes'][1]['start_s']-.001);alpha=1-ease(local/.24);outgoing.putalpha(outgoing.getchannel('A').point(lambda a:round(a*alpha)));im.alpha_composite(outgoing,(0,-round(H*.5*ease(local/.25))))
 im.alpha_composite(fg)
 return im.convert('RGB')

def note(freq,duration,kind='pluck',velocity=1):
 t=np.arange(round(duration*RATE))/RATE
 if kind=='pluck':
  mod=np.exp(-t*18)*1.4*np.sin(2*np.pi*freq*2*t);a=(np.sin(2*np.pi*freq*t+mod)+.22*np.sin(2*np.pi*freq*3*t)*np.exp(-t*10))*np.exp(-t*5.4)*(1-np.exp(-t*600))
 elif kind=='bass':a=(np.sin(2*np.pi*freq*t)+.12*np.sin(2*np.pi*freq*2*t))*np.exp(-t*3)*(1-np.exp(-t*120))
 else:a=np.sin(2*np.pi*freq*t)*np.exp(-t*7)*(1-np.exp(-t*500))
 return a*velocity

def audio_assets():
 count=RATE*DURATION;rng=np.random.default_rng(CFG['audio']['seed']);music=np.zeros((count,2));sfx=np.zeros((count,2));beat=60/104
 def place(bus,a,time,gain=1,pan=0):
  start=round(time*RATE)
  if start<0:a=a[-start:];start=0
  size=min(len(a),count-start)
  if size<=0:return
  if a.ndim==1:a=np.column_stack((a*np.sqrt((1-pan)/2),a*np.sqrt((1+pan)/2)))
  bus[start:start+size]+=a[:size]*gain
 def midi(n):return 440*2**((n-69)/12)
 # Original 26-beat arrangement at 104 BPM: Cmaj7 → Am7 → Fmaj7 → G7 → C.
 chords=[(0,8,[60,64,67,71]),(8,16,[57,60,64,67]),(16,22,[53,57,60,64]),(22,24,[55,59,62,65]),(24,26,[60,64,67,72])]
 for lo,hi,pitches in chords:
  for b in range(lo,hi):
   if b%2==0:place(music,note(midi(pitches[0]-24),.72,'bass'),b*beat,.23)
   for off,choice,vel in [(0,0,.21),(.75,1,.13),(1.5,2,.16)]:
    when=b+off
    if when>=hi or b%2:continue
    place(music,note(midi(pitches[(b//2+choice)%4]+12),.75),when*beat,vel,(-.25,.25,-.1)[choice])
  # Quiet harmonic wash sustains the tone, without a recognizable borrowed melody.
  tt=np.arange(round((hi-lo)*beat*RATE))/RATE;pad=np.zeros_like(tt)
  for p in pitches:pad+=np.sin(2*np.pi*midi(p)*tt+.07*np.sin(2*np.pi*.3*tt))/4
  env=np.minimum(1,tt/.25)*np.minimum(1,(tt[-1]-tt)/.38);place(music,pad*np.maximum(env,0),lo*beat,.065)
 for b in range(26):
  tt=np.arange(round(.22*RATE))/RATE;kick=np.sin(2*np.pi*(48*tt+35*.025*(1-np.exp(-tt/.025))))*np.exp(-tt*22);place(music,kick,b*beat,.13 if b%4 in [0,2] else .055)
  if b%2:
   no=rng.normal(size=round(.12*RATE));no=np.r_[0,np.diff(no)];tt=np.arange(len(no))/RATE;place(music,no*np.exp(-tt*45),b*beat,.014)
  for off in [.5]:
   no=rng.normal(size=round(.065*RATE));no=np.r_[0,np.diff(no)];tt=np.arange(len(no))/RATE;place(music,no*np.exp(-tt*100), (b+off)*beat,.008, .2 if b%2 else -.2)
 # Transitions are newly authored SFX, not unverified sounds attributed to v9.
 for event in EDL['audio_events']:
  kind=event['kind'];at=event['time_s']
  if 'whoosh' in kind or 'swipe' in kind:
   length=.42 if 'whoosh' in kind else .24;tt=np.arange(round(length*RATE))/RATE;no=rng.normal(size=len(tt));kernel=np.hanning(61);kernel/=kernel.sum();lo=np.convolve(no,kernel,'same');signal=(no*.20+lo*2)*np.sin(np.pi*tt/length)**2
   place(sfx,signal,at-length*.52,.16)
  elif kind=='chime':
   place(sfx,note(midi(84),.7,'chime'),at,.10,-.12);place(sfx,note(midi(88),.6,'chime'),at+.09,.06,.18)
  else:place(sfx,note(260,.18,'pluck'),at,.15)
 end=np.minimum(1,(np.arange(count)[::-1]/RATE)/.65);start=np.minimum(1,np.arange(count)/RATE/.04);music*= (start*end)[:,None];sfx*=end[:,None]
 wavfile.write(ROOT/'assets/music_original.wav',RATE,music.astype('float32'));wavfile.write(ROOT/'assets/sfx_original.wav',RATE,sfx.astype('float32'));mix=music+sfx;wavfile.write(ROOT/'assets/mix_raw.wav',RATE,mix.astype('float32'))
 return {'bpm':104,'beats':26,'seed':CFG['audio']['seed'],'duration_s':15,'source':'original synthesis in src/render.py; no catalog audio downloaded'}

def loudness(path):
 p=subprocess.run(['ffmpeg','-hide_banner','-i',str(path),'-vn','-af','loudnorm=I=-16:TP=-1.5:LRA=7:print_format=json','-f','null','-'],capture_output=True,check=True);s=p.stderr.decode();return json.loads(s[s.rfind('{'):s.rfind('}')+1])

def render_video(path):
 args=['ffmpeg','-v','error','-nostdin','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r','30','-i','-','-an','-vf','scale=out_color_matrix=bt709:out_range=tv','-c:v','libx264','-preset','medium','-crf','17','-threads','1','-pix_fmt','yuv420p','-color_range','tv','-colorspace','bt709','-color_trc','bt709','-color_primaries','bt709',str(path)]
 p=subprocess.Popen(args,stdin=subprocess.PIPE,stderr=subprocess.PIPE)
 try:
  for frame in range(FPS*DURATION):p.stdin.write(image_at(frame).tobytes())
  p.stdin.close();error=p.stderr.read();rc=p.wait()
  if rc:raise RuntimeError(error.decode())
 finally:
  if p.poll() is None:p.kill();p.wait()

def main():
 global W,H,S
 ap=argparse.ArgumentParser();ap.add_argument('--preview',action='store_true');ap.add_argument('--frames-only',action='store_true');args=ap.parse_args()
 if args.preview:W,H,S=360,640,.5
 work=pathlib.Path.cwd()/'work'/'sal-amargo';work.mkdir(parents=True,exist_ok=True)
 checks=ROOT/'review';checks.mkdir(exist_ok=True)
 for moment in [.8,2.8,5.9,8.9,12.8,14.7]:image_at(round(moment*FPS)).save(checks/f'frame_{moment:04.1f}.jpg',quality=95)
 if args.frames_only:return
 output=ROOT/('sal-amargo-previa.mp4' if args.preview else 'sal-amargo-criativo.mp4')
 if output.exists():raise FileExistsError(output)
 composition=audio_assets();raw=ROOT/'assets/mix_raw.wav';stats=loudness(raw)
 norm=(f'loudnorm=I=-16:TP=-1.5:LRA=7:measured_I={stats["input_i"]}:measured_TP={stats["input_tp"]}:measured_LRA={stats["input_lra"]}:measured_thresh={stats["input_thresh"]}:offset={stats["target_offset"]}:linear=true:print_format=summary')
 master=ROOT/'assets/mix_master.wav'
 if master.exists():master.unlink()
 command(['ffmpeg','-v','error','-i',raw,'-af',norm,'-ar','48000','-c:a','pcm_f32le',master])
 silent=work/('silent-preview.mp4' if args.preview else 'silent-main.mp4')
 if silent.exists():silent.unlink()
 render_video(silent)
 command(['ffmpeg','-v','error','-i',silent,'-i',master,'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-ar','48000','-t','15','-movflags','+faststart',output])
 measured=loudness(output)
 # Account for codec overs after measuring the actual AAC export.
 if float(measured['input_tp'])>-1.5:
  correction=-1.65-float(measured['input_tp']);revised=work/'corrected.mp4'
  if revised.exists():revised.unlink()
  command(['ffmpeg','-v','error','-i',silent,'-i',master,'-map','0:v:0','-map','1:a:0','-c:v','copy','-af',f'volume={correction}dB','-c:a','aac','-b:a','192k','-ar','48000','-t','15','-movflags','+faststart',revised]);revised.replace(output);measured=loudness(output)
 command(['ffmpeg','-v','error','-xerror','-i',output,'-f','null','-'])
 probe=json.loads(command(['ffprobe','-v','error','-show_format','-show_streams','-of','json',output]));source=ROOT/'assets/produto-original.jpg'
 report={'status':'rendered_technical_qc_passed_perceptual_audio_review_not_claimed','output':output.name,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'render':{'width_px':W,'height_px':H,'fps':'30/1','frames':450,'duration_s':15},'audio_composition':composition,'delivered_audio_measurements':{'integrated_lufs':float(measured['input_i']),'true_peak_dbtp':float(measured['input_tp']),'lra_lu':float(measured['input_lra']),'method':'loudnorm input analysis of final AAC stream'},'loudnorm_analysis_filter_report':measured,'probe':probe,'review_limits':['Frames/transitions reviewed; no claim of human full playback listening','Original 240x240 source limits label detail; source label was not regenerated'],'unused_resources':['HeyGen catalog audio: download blocked','ImageGen product cutout: rejected because fine print changed']}
 (ROOT/('qc-preview.json' if args.preview else 'qc.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({'output':str(output),'loudness':measured},indent=2))

if __name__=='__main__':main()
