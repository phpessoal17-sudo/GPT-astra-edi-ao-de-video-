# Criativo — Sal Amargo em cápsulas

Formato: vertical 9:16, 15 segundos, 30 fps. Peça de produto com texto editorial, trilha instrumental original e efeitos sonoros. Sem locução nesta versão.

| Tempo estimado | Texto exato na tela | Direção visual | Função sonora |
|---|---|---|---|
| 0,00–2,40 s | “Você já conhece?” / “Sal Amargo” | Frasco entra verticalmente; título em duas famílias tipográficas; círculo de baixa opacidade e faixa verde atrás | Abertura musical curta, acento suave na entrada |
| 2,40–5,20 s | “Sim, em” / “cápsulas.” | Reenquadramento aproxima o rótulo; produto à esquerda e palavra-chave à direita | Whoosh curto no reenquadramento; pluck na palavra |
| 5,20–8,20 s | “Olhe mais” / “de perto.” | Macro do rótulo dentro de cartão arredondado; arco pontilhado acompanha o detalhe visível, sem apresentar dados novos | Varrida leve e dois acentos discretos |
| 8,20–11,40 s | “Sal Amargo” / “em cápsulas” | Retorno ao frasco inteiro; cópias parciais fora das bordas criam profundidade, sem representar variedade de produtos | Acorde muda; whoosh acompanha a troca de escala |
| 11,40–15,00 s | “Conheça o produto” / “Saiba mais” | Hero final com rótulo desobstruído; CTA separado e sustentado; fundo claro e verde | Música resolve; toque final curto; fade de cauda |

## Base factual

- “Sal Amargo” e “cápsulas”: verificados visualmente no rótulo fornecido.
- A marca só aparece pela foto original; nenhum microtexto é reescrito.
- Gancho e CTA são redação publicitária proposta, sem promessa de efeito.
- A peça não demonstra uso, resultado clínico, quantidade interna ou recomendação de consumo.

## Relação com o DNA

v9.event.001/002: recorte central, fundo claro/verde e hierarquia sans/serifada. v9.event.003: entrada vertical com desaceleração; a trajetória medida é adaptada à legibilidade do frasco. v9.event.008: mudança de escala e palavra de destaque. Áudio foi criado para esta peça e não é apresentado como extração do áudio da referência.
