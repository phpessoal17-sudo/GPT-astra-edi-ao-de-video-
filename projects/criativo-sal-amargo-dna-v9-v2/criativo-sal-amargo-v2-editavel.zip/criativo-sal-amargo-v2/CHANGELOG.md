# Changelog

## 2.0.0 — 30/10/2026

- Revisão solicitada: narração, imagem de maior definição, mudanças por frase, cenários e animação com profundidade por código.
- Preserva v1 e arquivos originais.
- ElevenLabs consultada e tentativa registrada sem geração/cobrança; alternativa usa narração já existente no repositório.
- Tentativa de restauração por IA rejeitada por mutação do rótulo; referência aprimorada anterior reutilizada com limites declarados.
- Preferências persistidas em AGENTS, workflow, knowledge e skill portátil.
- Revisão do primeiro master encontrou campo de transição sobre a legenda por poucos frames. Texto passou a ser composto depois da transição; master refeito e novamente verificado.
- Projeção do torus vetorizada para reduzir cálculo redundante, mantendo geometria e profundidade.
