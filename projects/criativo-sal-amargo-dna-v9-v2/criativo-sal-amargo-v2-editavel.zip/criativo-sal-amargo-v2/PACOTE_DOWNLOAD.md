# Pacote editavel

O MP4 final e baixado separadamente. Coloque sal-amargo-v2.mp4 na pasta extraida para usar index.html.

Este ZIP preserva a foto original, o packshot HD usado, as duas imagens de apoio, fontes/licencas, perfil de DNA, roteiro, EDL, legendas, codigo, relatorios e instrucoes reutilizaveis.

Audio separado: narration-original.wav e a voz original (mono, 24 kHz); music-stem.flac e sfx-stem.flac sao os stems de intercambio em PCM de 24 bits. O codec FLAC preserva esses 24 bits; nao se afirma identidade bit a bit com os intermediarios float32. O codigo regenera voz/musica/SFX/mix em float32 a 48 kHz.

Foram omitidos somente videos duplicados, imagens derivadas de QC/caches e intermediarios de audio regeneraveis. O arquivo original de voz e mantido sem alteracao. Os resultados de QC se referem ao MP4 final, nao a uma renderizacao futura em outro ambiente.

Veja README.md para reconstruir e references/ para origem, preferencias e limites.
